#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>
#include <iomanip>

using namespace std;

const int MAX_STUDENTS_PER_COURSE = 100;



struct Date {
    int day, month, year;

    void print(ostream& os) {
        os << day << "/" << month << "/" << year;
    }


    bool isOlderThan(Date other) {
        if (year != other.year) return year < other.year;
        if (month != other.month) return month < other.month;
        return day < other.day;
    }
};

struct Student {
    char id[20];
    char fullName[50];
    char className[10];
    double gpa;
    Date dob;


    bool firstNameComesBefore(Student other) {

        int myNameStart = 0;
        for (int i = 0; fullName[i] != '\0'; i++) {
            if (fullName[i] == ' ') myNameStart = i + 1;
        }


        int otherNameStart = 0;
        for (int i = 0; other.fullName[i] != '\0'; i++) {
            if (other.fullName[i] == ' ') otherNameStart = i + 1;
        }


        return strcmp(&fullName[myNameStart], &other.fullName[otherNameStart]) < 0;
    }
};

struct Course {
    char id[20];
    char name[100];

    Student students[MAX_STUDENTS_PER_COURSE];
    char status[30];
    int maxStudents;
    int minStudents;
    int currentCount;


    Course() {
        currentCount = 0;
        maxStudents = MAX_STUDENTS_PER_COURSE;
        minStudents = 0;
        strcpy(status, "Unknown");
    }


    void updateStatus() {
        if (currentCount < minStudents) {
            strcpy(status, "Closed (Under Minimum)");
        }
        else if (currentCount >= maxStudents) {
            strcpy(status, "Closed (Full)");
        }
        else {
            strcpy(status, "Open");
        }
    }
};


void inputCourseFromFile(Course& c, char filename[]);
void outputCourseToFile(Course& c, char filename[]);
void addStudent(Course& c, Student s);
void removeStudent(Course& c, char studentId[]);
void findBornInMonth(Course& c);
void findBornToday(Course& c);
void findLegalDrivingAge(Course& c);
void findStudentsByClass(Course& c, char className[], char outfile[]);
void findStudentById(Course& c, char id[], char outfile[]);
void findStudentByName(Course& c, char nameQuery[], char outfile[]);


void sortStudentsById(Course& c, char outfile[]);
void sortStudentsByFirstName(Course& c, char outfile[]);
void sortStudentsByGPA(Course& c, char outfile[]);
void sortStudentsByDOB(Course& c, char outfile[]);



Date getCurrentDate() {
    time_t t = time(0);
    tm now;

    now = *localtime(&t);
    return { now.tm_mday, now.tm_mon + 1, now.tm_year + 1900 };
}

void printHeader(ostream& os) {
    os << left << setw(15) << "ID"
        << setw(25) << "Name"
        << setw(10) << "Class"
        << setw(6) << "GPA"
        << setw(12) << "DOB" << endl;
}

void printStudent(ostream& os, Student s) {
    os << left << setw(15) << s.id
        << setw(25) << s.fullName
        << setw(10) << s.className
        << setw(6) << setprecision(2) << fixed << s.gpa;
    s.dob.print(os);
    os << endl;
}

void swapStudents(Student& a, Student& b) {
    Student temp = a;
    a = b;
    b = temp;
}



void inputCourseFromFile(Course& c, char filename[]) {
    ifstream fin(filename);
    if (!fin.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    fin.getline(c.id, 20);
    fin.getline(c.name, 100);
    fin >> c.minStudents >> c.maxStudents;


    if (c.maxStudents > MAX_STUDENTS_PER_COURSE) {
        c.maxStudents = MAX_STUDENTS_PER_COURSE;
    }

    int tempCount;
    fin >> tempCount;
    fin.ignore();

    c.currentCount = 0;
    for (int i = 0; i < tempCount; ++i) {
        if (i >= c.maxStudents) break;

        Student s;
        fin.getline(s.id, 20);
        fin.getline(s.fullName, 50);
        fin.getline(s.className, 10);
        fin >> s.gpa >> s.dob.day >> s.dob.month >> s.dob.year;
        fin.ignore();


        c.students[i] = s;
        c.currentCount++;
    }

    fin.close();
    c.updateStatus();
    cout << "Course loaded successfully from " << filename << endl;
}

void outputCourseToFile(Course& c, char filename[]) {
    ofstream fout(filename);
    if (!fout.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }
    fout << "Min: " << c.minStudents << ", Max: " << c.maxStudents
        << ", Current: " << c.currentCount << endl;
    fout << endl << "Student List:" << endl;

    printHeader(fout);
    for (int i = 0; i < c.currentCount; ++i) {
        printStudent(fout, c.students[i]);
    }

    fout.close();
    cout << "Course info saved to " << filename << endl;
}

void addStudent(Course& c, Student s) {
    if (c.currentCount >= c.maxStudents) {
        cout << "Failed to add student " << s.fullName << ": Course is full." << endl;
        return;
    }
    c.students[c.currentCount] = s;
    c.currentCount++;
    c.updateStatus();
    cout << "Student " << s.fullName << " added." << endl;
}

void removeStudent(Course& c, char studentId[]) {
    int index = -1;
    for (int i = 0; i < c.currentCount; ++i) {
        if (strcmp(c.students[i].id, studentId) == 0) {
            index = i;
            break;
        }
    }

    if (index != -1) {

        for (int i = index; i < c.currentCount - 1; ++i) {
            c.students[i] = c.students[i + 1];
        }
        c.currentCount--;
        c.updateStatus();
        cout << "Student " << studentId << " removed." << endl;
    }
    else {
        cout << "Student " << studentId << " not found." << endl;
    }
}

void findBornInMonth(Course& c) {
    Date current = getCurrentDate();
    cout << "\n--- Students born in current month (" << current.month << ") ---" << endl;
    printHeader(cout);
    bool found = false;
    for (int i = 0; i < c.currentCount; ++i) {
        if (c.students[i].dob.month == current.month) {
            printStudent(cout, c.students[i]);
            found = true;
        }
    }
    if (!found) cout << "No students found." << endl;
}

void findBornToday(Course& c) {
    Date current = getCurrentDate();
    cout << "\n--- Students born today (" << current.day << "/" << current.month << ") ---" << endl;
    printHeader(cout);
    bool found = false;
    for (int i = 0; i < c.currentCount; ++i) {
        if (c.students[i].dob.day == current.day && c.students[i].dob.month == current.month) {
            printStudent(cout, c.students[i]);
            found = true;
        }
    }
    if (!found) cout << "No students found." << endl;
}

void findLegalDrivingAge(Course& c) {
    Date current = getCurrentDate();
    cout << "\n--- Students eligible for driving license (>= 18) ---" << endl;
    printHeader(cout);
    bool found = false;
    for (int i = 0; i < c.currentCount; ++i) {
        int age = current.year - c.students[i].dob.year;
        if (current.month < c.students[i].dob.month ||
            (current.month == c.students[i].dob.month && current.day < c.students[i].dob.day)) {
            age--;
        }

        if (age >= 18) {
            printStudent(cout, c.students[i]);
            found = true;
        }
    }
    if (!found) cout << "No students found." << endl;
}

void findStudentsByClass(Course& c, char className[], char outfile[]) {
    ofstream fout(outfile);
    fout << "Students in class: " << className << endl;
    printHeader(fout);
    for (int i = 0; i < c.currentCount; ++i) {
        if (strcmp(c.students[i].className, className) == 0) {
            printStudent(fout, c.students[i]);
        }
    }
    cout << "Class filter saved to " << outfile << endl;
}

void findStudentById(Course& c, char id[], char outfile[]) {
    ofstream fout(outfile);
    fout << "Search result for ID: " << id << endl;
    printHeader(fout);
    for (int i = 0; i < c.currentCount; ++i) {
        if (strcmp(c.students[i].id, id) == 0) {
            printStudent(fout, c.students[i]);
            break;
        }
    }
    cout << "ID search saved to " << outfile << endl;
}

void findStudentByName(Course& c, char nameQuery[], char outfile[]) {
    ofstream fout(outfile);
    fout << "Search result for Name containing: '" << nameQuery << "'" << endl;
    printHeader(fout);

    for (int i = 0; i < c.currentCount; ++i) {
        if (strstr(c.students[i].fullName, nameQuery) != nullptr) {
            printStudent(fout, c.students[i]);
        }
    }
    cout << "Name search saved to " << outfile << endl;
}



void sortStudentsById(Course& c, char outfile[]) {
    for (int i = 0; i < c.currentCount - 1; i++) {
        for (int j = 0; j < c.currentCount - i - 1; j++) {
            if (strcmp(c.students[j].id, c.students[j + 1].id) > 0) {
                swapStudents(c.students[j], c.students[j + 1]);
            }
        }
    }
    outputCourseToFile(c, outfile);
    cout << "Sorted by ID." << endl;
}

void sortStudentsByFirstName(Course& c, char outfile[]) {
    for (int i = 0; i < c.currentCount - 1; i++) {
        for (int j = 0; j < c.currentCount - i - 1; j++) {
            if (!c.students[j].firstNameComesBefore(c.students[j + 1])) {

                if (c.students[j + 1].firstNameComesBefore(c.students[j])) {
                    swapStudents(c.students[j], c.students[j + 1]);
                }
            }
        }
    }
    outputCourseToFile(c, outfile);
    cout << "Sorted by First Name." << endl;
}

void sortStudentsByGPA(Course& c, char outfile[]) {
    for (int i = 0; i < c.currentCount - 1; i++) {
        for (int j = 0; j < c.currentCount - i - 1; j++) {
            if (c.students[j].gpa < c.students[j + 1].gpa) {
                swapStudents(c.students[j], c.students[j + 1]);
            }
        }
    }
    outputCourseToFile(c, outfile);
    cout << "Sorted by GPA." << endl;
}

void sortStudentsByDOB(Course& c, char outfile[]) {
    for (int i = 0; i < c.currentCount - 1; i++) {
        for (int j = 0; j < c.currentCount - i - 1; j++) {
            if (c.students[j + 1].dob.isOlderThan(c.students[j].dob)) {
                swapStudents(c.students[j], c.students[j + 1]);
            }
        }
    }
    outputCourseToFile(c, outfile);
    cout << "Sorted by DOB." << endl;
}



int main() {
    Course myCourse;



    char inputFile[] = "course_input.txt";
    inputCourseFromFile(myCourse, inputFile);



    char choice;
    do {
        cout << "\nDo you want to add a new student? (y/n): ";
        cin >> choice;
        cin.ignore();

        if (choice == 'y' || choice == 'Y') {
            Student newS;

            cout << "Enter Student ID: ";
            cin.getline(newS.id, 20);

            cout << "Enter Full Name: ";
            cin.getline(newS.fullName, 50);

            cout << "Enter Class Name: ";
            cin.getline(newS.className, 10);

            cout << "Enter GPA: ";
            cin >> newS.gpa;

            cout << "Enter DOB (day month year): ";
            cin >> newS.dob.day >> newS.dob.month >> newS.dob.year;
            cin.ignore();

            addStudent(myCourse, newS);
        }

    } while (choice == 'y' || choice == 'Y');

    char removeId[] = "18127001";
    cout << "\nAttempting to remove student ID: " << removeId << "..." << endl;
    removeStudent(myCourse, removeId);

    char outputFile[] = "course_output_c.txt";
    outputCourseToFile(myCourse, outputFile);

    findBornInMonth(myCourse);
    findBornToday(myCourse);
    findLegalDrivingAge(myCourse);

    char classK19[] = "K19";
    char outK19[] = "out_k19.txt";
    findStudentsByClass(myCourse, classK19, outK19);

    char searchId[] = "20127005";
    char outId[] = "out_id.txt";
    findStudentById(myCourse, searchId, outId);

    char searchName[] = "Thanh";
    char outName[] = "out_name.txt";
    findStudentByName(myCourse, searchName, outName);


    char outSortId[] = "out_sort_id.txt";
    sortStudentsById(myCourse, outSortId);

    char outSortName[] = "out_sort_name.txt";
    sortStudentsByFirstName(myCourse, outSortName);

    char outSortGpa[] = "out_sort_gpa.txt";
    sortStudentsByGPA(myCourse, outSortGpa);

    char outSortDob[] = "out_sort_dob.txt";
    sortStudentsByDOB(myCourse, outSortDob);



    return 0;
}