#include <iostream>

using namespace std;


int* expandArray(const int* originalArray, int size) {
    int newSize = size * 2;

    int* newArray = new int[newSize];  // chua release

 
    for (int i = 0; i < size; i++) {
        newArray[i] = originalArray[i];
    }

    for (int i = size; i < newSize; i++) {
        newArray[i] = 0;
    }

    return newArray;
}

int main() {
    int size;

    cout << "Enter the size of the array: ";
    cin >> size;

    int* myArray = new int[size];  //chua release

    
    for (int i = 0; i < size; i++) {
        cin >> myArray[i];
    }

    
    cout << "\nOriginal Array: ";
    for (int i = 0; i < size; i++) {
        cout << myArray[i] << " ";
    }
    cout << endl;

    
    int* expandedArray = expandArray(myArray, size);

   
    cout << "Expanded Array : ";
    for (int i = 0; i < size * 2; i++) {
        cout << expandedArray[i] << " ";
    }
    cout << endl;

    

    delete[] myArray;  //
    delete[] expandedArray;  //
    return 0;  
}