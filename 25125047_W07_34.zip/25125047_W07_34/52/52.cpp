#include <iostream>
#include <fstream>
#include <iomanip> 

using namespace std;


bool readAnswers(const char* filename, char*& answers, int& numQuestions) {
    ifstream inputFile;
    inputFile.open(filename);

    if (!inputFile) {
        cout << "Error: Could not open file " << filename << endl;
        return false;
    }

 
    if (!(inputFile >> numQuestions)) {
        cout << "Error: Could not read the number of questions from " << filename << endl;
        return false;
    }

    
    answers = new char[numQuestions];

    for (int i = 0; i < numQuestions; i++) {
        inputFile >> answers[i];
    }

    inputFile.close();
    return true;
}

int main() {
   
    char* correctAnswers = nullptr;
    char* studentAnswers = nullptr;

  
    int correctCount = 0;
    int studentCount = 0;

   
    if (!readAnswers("CorrectAnswers.txt", correctAnswers, correctCount)) {
        return 1;
    }

   
    if (!readAnswers("StudentAnswers.txt", studentAnswers, studentCount)) {
        
        delete[] correctAnswers;
        return 1; 
    }

    
    if (correctCount != studentCount) {
        cout << "Number unmatched !" << endl;
       
        delete[] correctAnswers;
        delete[] studentAnswers;
        return 1;
    }

    int totalQuestions = correctCount;
    int missedCount = 0;

    cout << " EXAM RESULTS                 :" << endl;
 

   
    for (int i = 0; i < totalQuestions; i++) {
        if (correctAnswers[i] != studentAnswers[i]) {
            missedCount++;
            cout << (i + 1) << "\t" << correctAnswers[i] << "\t" << studentAnswers[i] << endl;
        }
    }

    if (missedCount == 0) {
        cout << "Perfect score!" << endl;
    }

  
    int correctAnswersCount = totalQuestions - missedCount;
    double percentage = (static_cast<double>(correctAnswersCount) / totalQuestions) * 100.0;

    cout << "--------------------------------------------------" << endl;
    cout << "Total Questions Missed: " << missedCount << endl;
    cout << "Questions Answered Correctly: " << correctAnswersCount << " / " << totalQuestions << endl;
    cout << "Percentage: " << fixed << setprecision(2) << percentage << "%" << endl;

  
    cout << "Final Grade: ";
    if (percentage >= 70.0) {
        cout << "PASS" << endl;
    }
    else {
        cout << "FAIL" << endl;
    }

   
    delete[] correctAnswers;
    delete[] studentAnswers;

    return 0;
}