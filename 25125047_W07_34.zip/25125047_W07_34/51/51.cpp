#include <iostream>

using namespace std;


void printArray(int* arr, int n) {
    if (n == 0) {
        cout << "[Empty Array]" << endl;
        return;
    }
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int n;

    cout << "Enter the size of the array (n): ";
    cin >> n;

    if (n <= 0) {
        cout << "Invalid size! " << endl;
        return 0;
    }

    int* arr = new int[n];

    cout << "2. Input your array: " << endl;
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }


    cout << "3. Print all the array " << endl;;
    printArray(arr, n);


    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    cout << "4. Sum of elements: " << sum << endl;


    int maxVal = arr[0];
    int maxIndex = 0;
    for (int i = 1; i < n; i++) {
        if (arr[i] > maxVal) {
            maxVal = arr[i];
            maxIndex = i;
        }
    }
    cout << "5. Largest value: " << maxVal << endl;

    for (int i = maxIndex; i < n - 1; i++) {
        arr[i] = arr[i + 1];
    }
    n--;

    cout << "6. Array after deleting largest value: ";
    printArray(arr, n);


    int newVal, pos;

    cout << "7. Enter value to insert: ";
    cin >> newVal;
    cout << "Enter index position (0 - " << n << "): ";
    cin >> pos;

    if (pos < 0 || pos > n) {
        cout << "Error: Invalid position! " << endl;
    }
    else {
        int* newArr = new int[n + 1];


        for (int i = 0; i < pos; i++) {
            newArr[i] = arr[i];
        }

        newArr[pos] = newVal;


        for (int i = pos; i < n; i++) {
            newArr[i + 1] = arr[i];
        }


        delete[] arr;


        arr = newArr;
        n++;

        cout << "Array after insertion: ";
        printArray(arr, n);
    }


    int start = 0;
    int end = n - 1;
    while (start < end) {
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;


        start++;
        end--;
    }

    cout << "8. Array after reversing: ";
    printArray(arr, n);


    delete[] arr;

    return 0;
}